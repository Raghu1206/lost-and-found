# Oasis
_Connecting students, filling gaps of closed doors by tech to step up the first talk; just like an OASIS in middle of a Vast Dessert; A hope._<br>
Why join the hassle of using multiple portals on multiple platforms?? Cant thou just use OASIS!

- [Oasis v0.0](https://github.com/Hyouteki/Oasis/blob/main/Oasis.apk) [Application download link]: Stable verison but not ready for the final release; check [TODO.md](https://github.com/Hyouteki/Oasis/blob/main/TODO.md) to track the progress.
- [Oasis Dev](https://github.com/Hyouteki/Oasis/tree/master): Ahead of the current stable version but still in development, it will be merged with the main branch once it is stable.
- [Metadata](https://github.com/Hyouteki/Oasis/blob/main/output-metadata.json)
