# Stack
> things that are not so important; but will improve the app

- [ ] icon for more; by default profile icon but inside more fragment it become more
- [ ] good as new, not half bad, it is what it is [conditions]
