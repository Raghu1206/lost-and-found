# TODO
> these TODOs will eventually become more descriptive when reaching to that stage

## v0.0
> basic app and essential ui/ux components setup
- [x] app setup
- [x] firebase setup
- [x] theming and colors
- [x] sign in activity + layout
- [x] bottom navigation bar setup
- [x] more fragment layout
- [x] modal bottom sheets setup
- [x] more bottom sheet layout
- [x] marketplace bottom sheet layout
- [x] happening bottom sheet layout
- [x] choose user bottom sheet layout
- [x] add fragment layout
- [x] able to sign out

## v0.1
> marketplace
- [x] add marketplace activity + layout
- [ ] save as draft and load from draft
- [ ] load add marketplace post from marketplace fragment
- [ ] marketplace fragment
- [ ] update/delete posts
- [ ] lost/found
- [ ] sorting mechanism
- [ ] history

## v0.2
> chat

## v0.3
> confessions/happening
